import React from "react";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>프로필</h2>
      <button onClick={logout} style={styles.btn}>로그아웃</button>
    </div>
  );
}

const styles = {
  btn: {
    marginTop: 20,
    padding: "10px 20px",
    borderRadius: "10px",
    border: "none",
    backgroundColor: "#f44336",
    color: "#fff",
    cursor: "pointer",
  },
};
