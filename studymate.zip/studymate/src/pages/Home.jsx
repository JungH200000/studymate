import React, { useState } from "react";
import BottomNav from "../components/BottomNav";

export default function Home() {
  const [tab, setTab] = useState("home");

  return (
    <div>
      {tab === "profile" && <p>프로필로 이동하려면 아래 프로필 아이콘을 눌러주세요</p>}
      <BottomNav setTab={setTab} />
    </div>
  );
}
