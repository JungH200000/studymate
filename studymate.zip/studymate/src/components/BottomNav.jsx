import React from "react";

export default function BottomNav({ setTab }) {
  return (
    <div style={styles.nav}>
      <button onClick={() => setTab("home")}>🏠 홈</button>
      <button onClick={() => setTab("write")}>✏️ 글쓰기</button>
      <button onClick={() => (window.location.href = "/profile")}>👤 프로필</button>
    </div>
  );
}

const styles = {
  nav: {
    position: "fixed",
    bottom: 0,
    width: "100%",
    display: "flex",
    justifyContent: "space-around",
    padding: "10px 0",
    backgroundColor: "#f8f8f8",
    borderTop: "1px solid #ccc",
  },
};
